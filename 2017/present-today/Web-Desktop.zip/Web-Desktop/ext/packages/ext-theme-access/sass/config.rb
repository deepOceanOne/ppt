cur_dir = File.dirname(__FILE__)
css_path = $css_path = File.join(cur_dir, '..', 'build', 'resources')
output_style = :nested
require File.join(cur_dir, '..', '..', 'ext-theme-base', 'sass', 'utils.rb')
Ext.define('EJS.controller.Main', {
    extend: 'Ext.app.Controller'
});
